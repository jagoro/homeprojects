var imagenes = new Array(3)
imagenes[0] = "Volando.png"
imagenes[1] = "Necesario.png"
imagenes[2] = "Jose.png"
var musica = new Array(3)
musica[0] = ""
musica[1] = ""
musica[2] = ""
var info = new Array(3)
info[0] = ""
info[1] = ""
info[2] = ""

cont=0
function Siguiente(){
  document.getElementById("foto").src=imagenes[cont];
  if (cont < imagenes.length-1)
  {
    cont ++
    alert()
  }
  else
  {
    cont=0
  }
}
